# Hirshfeld Charge Database Web GUI

Web界面用于查询和可视化Hirshfeld电荷数据库。

## 目录结构

```
hirshfeld_webgui/
├── app.py                      # Flask后端服务
├── h.db                        # ASE数据库文件
├── templates/
│   └── index.html             # 前端页面
├── static/
│   ├── css/
│   │   └── style.css          # 样式表
│   └── js/
│       └── app.js             # 前端交互逻辑
├── extract_hirshfeld.py       # Hirshfeld数据提取脚本
├── check_hirshfeld.py         # 数据检查脚本
└── README.md                  # 本文件
```

## 依赖要求

- Python 3.7+
- Flask
- ASE (Atomic Simulation Environment)
- h5py
- numpy

安装依赖：
```bash
pip install flask ase h5py numpy
```

## 使用方法

### 1. 启动Web服务

```bash
python app.py
```

或使用特定的Python环境：
```bash
~/app/anaconda/anaconda3/envs/py14/bin/python app.py
```

### 2. 访问Web界面

在浏览器中打开：
- 本地访问: http://localhost:5000
- 远程访问: http://<服务器IP>:5000

### 3. 功能说明

- **统计仪表盘**: 显示数据库统计信息
- **材料列表**: 分页浏览所有材料（每页20条）
- **搜索功能**: 按MPID或化学式搜索
- **详情查看**: 点击材料查看详细的Hirshfeld电荷数据

### 4. 提取新数据（可选）

如果需要重新提取Hirshfeld数据：

```bash
python extract_hirshfeld.py
```

脚本会从 `hchg/{mpid}/scf/scf/vaspout.h5` 读取数据并更新 `h.db`。

### 5. 检查数据（可选）

验证数据库中的Hirshfeld数据：

```bash
python check_hirshfeld.py
```

## 数据说明

数据库中存储了4种Hirshfeld电荷数据：

1. **hirshfeld**: 标准Hirshfeld电荷
2. **hirshfeld_i**: 迭代Hirshfeld电荷
3. **hirshfeld_i_relvol**: 迭代Hirshfeld相对体积
4. **hirshfeld_relvol**: Hirshfeld相对体积

每个材料的数据都以原子为单位存储在ASE数据库的data字段中。

## 配置选项

可以在 `app.py` 中修改：

- `DB_PATH`: 数据库文件路径（默认: 'h.db'）
- `host`: 服务器地址（默认: '0.0.0.0'）
- `port`: 端口号（默认: 5000）
- `debug`: 调试模式（默认: True）

生产环境建议设置 `debug=False`。

## 故障排除

### 问题1: 无法启动服务
- 检查Python环境是否安装了Flask
- 确认端口5000未被占用

### 问题2: 无法访问Web界面
- 检查防火墙设置
- 确认服务器IP地址正确
- 尝试使用 `0.0.0.0` 作为host

### 问题3: 数据库为空
- 确认 h.db 文件存在
- 运行 check_hirshfeld.py 检查数据

## 许可证

本项目仅供学术研究使用。

## 联系方式

如有问题，请联系开发者。
