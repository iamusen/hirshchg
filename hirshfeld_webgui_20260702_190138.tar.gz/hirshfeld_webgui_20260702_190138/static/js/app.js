let currentPage = 1;
let totalPages = 1;
let perPage = 20;
let currentSearch = '';

// 初始化
document.addEventListener('DOMContentLoaded', function() {
    loadStats();
    loadMaterials();

    // 搜索功能
    document.getElementById('search-btn').addEventListener('click', handleSearch);
    document.getElementById('clear-btn').addEventListener('click', handleClear);
    document.getElementById('search-input').addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            handleSearch();
        }
    });
});

// 加载统计信息
async function loadStats() {
    try {
        const response = await fetch('/api/stats');
        const data = await response.json();

        document.getElementById('total-count').textContent = data.total;
        document.getElementById('hirshfeld-count').textContent = data.with_hirshfeld;
        document.getElementById('coverage').textContent = data.percentage + '%';
    } catch (error) {
        console.error('Error loading stats:', error);
    }
}

// 加载材料列表
async function loadMaterials(page = 1) {
    currentPage = page;

    try {
        const response = await fetch(`/api/materials?page=${page}&per_page=${perPage}&search=${currentSearch}`);
        const data = await response.json();

        totalPages = data.total_pages;

        const tbody = document.getElementById('materials-tbody');
        tbody.innerHTML = '';

        if (data.materials.length === 0) {
            tbody.innerHTML = '<tr><td colspan="5" class="loading">No materials found</td></tr>';
            return;
        }

        data.materials.forEach(material => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td><code>${material.mpid || 'N/A'}</code></td>
                <td>${material.formula}</td>
                <td>${material.n_atoms}</td>
                <td><span class="badge ${material.has_hirshfeld ? 'badge-yes' : 'badge-no'}">${material.has_hirshfeld ? 'Yes' : 'No'}</span></td>
                <td><button class="btn-view" onclick="loadDetail(${material.id})">View</button></td>
            `;
            tr.addEventListener('click', () => loadDetail(material.id));
            tbody.appendChild(tr);
        });

        updatePagination();

    } catch (error) {
        console.error('Error loading materials:', error);
    }
}

// 更新分页
function updatePagination() {
    const paginationHTML = `
        <button onclick="loadMaterials(1)" ${currentPage === 1 ? 'disabled' : ''}>First</button>
        <button onclick="loadMaterials(${currentPage - 1})" ${currentPage === 1 ? 'disabled' : ''}>Prev</button>
        <span>Page ${currentPage} of ${totalPages}</span>
        <button onclick="loadMaterials(${currentPage + 1})" ${currentPage === totalPages ? 'disabled' : ''}>Next</button>
        <button onclick="loadMaterials(${totalPages})" ${currentPage === totalPages ? 'disabled' : ''}>Last</button>
    `;

    document.getElementById('top-pagination').innerHTML = paginationHTML;
    document.getElementById('bottom-pagination').innerHTML = paginationHTML;
}

// 加载材料详情
async function loadDetail(rowId) {
    // 高亮选中行
    document.querySelectorAll('#materials-tbody tr').forEach(tr => tr.classList.remove('selected'));
    event.target.closest('tr')?.classList.add('selected');

    try {
        const response = await fetch(`/api/material/${rowId}`);
        const data = await response.json();

        if (data.error) {
            showError(data.error);
            return;
        }

        renderDetail(data);

    } catch (error) {
        console.error('Error loading detail:', error);
        showError('Failed to load material details');
    }
}

// 渲染详情
function renderDetail(data) {
    const detailContent = document.getElementById('detail-content');

    let html = `
        <div class="detail-section">
            <h3>Basic Information</h3>
            <div class="detail-grid">
                <div class="detail-item">
                    <span class="detail-label">MPID:</span>
                    <span class="detail-value"><code>${data.mpid || 'N/A'}</code></span>
                </div>
                <div class="detail-item">
                    <span class="detail-label">Formula:</span>
                    <span class="detail-value">${data.formula}</span>
                </div>
                <div class="detail-item">
                    <span class="detail-label">Atoms:</span>
                    <span class="detail-value">${data.n_atoms}</span>
                </div>
                <div class="detail-item">
                    <span class="detail-label">Row ID:</span>
                    <span class="detail-value">${data.id}</span>
                </div>
            </div>
        </div>
    `;

    // Hirshfeld 数据
    if (data.hirshfeld) {
        html += `
            <div class="detail-section">
                <h3>Hirshfeld Charge Data</h3>
                <table class="hirshfeld-table">
                    <thead>
                        <tr>
                            <th>Atom</th>
                            <th>Symbol</th>
                            <th>Hirshfeld</th>
                            <th>Hirshfeld_i</th>
                            <th>H_i_RelVol</th>
                            <th>H_RelVol</th>
                        </tr>
                    </thead>
                    <tbody>
        `;

        const n = data.hirshfeld.hirshfeld.length;
        for (let i = 0; i < n; i++) {
            const symbol = data.symbols[i] || '?';
            html += `
                <tr>
                    <td>${i + 1}</td>
                    <td class="atom-symbol">${symbol}</td>
                    <td>${data.hirshfeld.hirshfeld[i].toFixed(4)}</td>
                    <td>${data.hirshfeld.hirshfeld_i[i].toFixed(4)}</td>
                    <td>${data.hirshfeld.hirshfeld_i_relvol[i].toFixed(4)}</td>
                    <td>${data.hirshfeld.hirshfeld_relvol[i].toFixed(4)}</td>
                </tr>
            `;
        }

        html += `
                    </tbody>
                </table>
            </div>
        `;
    }

    // 原子信息
    if (data.symbols && data.symbols.length > 0) {
        html += `
            <div class="detail-section">
                <h3>Atomic Structure</h3>
                <div class="detail-item">
                    <span class="detail-label">Symbols:</span>
                    <span class="detail-value">${data.symbols.join(', ')}</span>
                </div>
                <div class="detail-item">
                    <span class="detail-label">Numbers:</span>
                    <span class="detail-value">${data.numbers.join(', ')}</span>
                </div>
            </div>
        `;
    }

    // 其他属性
    if (data.properties && Object.keys(data.properties).length > 0) {
        html += `
            <div class="detail-section">
                <h3>Additional Properties</h3>
                <pre>${JSON.stringify(data.properties, null, 2)}</pre>
            </div>
        `;
    }

    detailContent.innerHTML = html;
}

// 搜索
function handleSearch() {
    currentSearch = document.getElementById('search-input').value.trim();
    loadMaterials(1);
}

// 清除搜索
function handleClear() {
    document.getElementById('search-input').value = '';
    currentSearch = '';
    loadMaterials(1);
}

// 显示错误
function showError(message) {
    const detailContent = document.getElementById('detail-content');
    detailContent.innerHTML = `<p class="placeholder" style="color: #dc3545;">${message}</p>`;
}
