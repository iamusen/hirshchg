#!/share/home/limusen/app/anaconda/anaconda3/envs/py14/bin/python
from flask import Flask, render_template, request, jsonify
from ase.db import connect
import json
import numpy as np

app = Flask(__name__)

DB_PATH = 'h.db'

def get_db():
    """获取数据库连接"""
    return connect(DB_PATH)

def convert_to_json_serializable(obj):
    """转换numpy类型为Python原生类型"""
    if isinstance(obj, np.integer):
        return int(obj)
    elif isinstance(obj, np.floating):
        return float(obj)
    elif isinstance(obj, np.ndarray):
        return obj.tolist()
    elif isinstance(obj, list):
        return [convert_to_json_serializable(item) for item in obj]
    elif isinstance(obj, dict):
        return {key: convert_to_json_serializable(value) for key, value in obj.items()}
    else:
        return obj

@app.route('/')
def index():
    """主页面"""
    return render_template('index.html')

@app.route('/api/stats')
def get_stats():
    """获取数据库统计信息"""
    db = get_db()

    total_count = db.count()

    # 统计包含hirshfeld数据的数量
    hirshfeld_count = 0
    for row in db.select():
        if row.data and 'hirshfeld' in row.data:
            hirshfeld_count += 1

    return jsonify({
        'total': total_count,
        'with_hirshfeld': hirshfeld_count,
        'percentage': round(100 * hirshfeld_count / total_count, 1) if total_count > 0 else 0
    })

@app.route('/api/materials')
def get_materials():
    """获取材料列表（分页）"""
    db = get_db()

    page = int(request.args.get('page', 1))
    per_page = int(request.args.get('per_page', 20))
    search = request.args.get('search', '').strip()

    # 收集所有材料
    materials = []
    for row in db.select():
        mpid = None
        if hasattr(row, 'mpid'):
            mpid = row.mpid
        elif 'mpid' in row.key_value_pairs:
            mpid = row.key_value_pairs['mpid']
        elif 'mpid' in row.data:
            mpid = row.data['mpid']

        # 搜索过滤
        if search and mpid and search.lower() not in mpid.lower():
            continue

        # 获取基本信息
        formula = row.formula if hasattr(row, 'formula') else 'N/A'
        n_atoms = len(row.numbers) if hasattr(row, 'numbers') else 0

        # 检查是否有hirshfeld数据
        has_hirshfeld = row.data and 'hirshfeld' in row.data

        materials.append({
            'id': row.id,
            'mpid': mpid,
            'formula': formula,
            'n_atoms': n_atoms,
            'has_hirshfeld': has_hirshfeld
        })

    # 分页
    total = len(materials)
    start = (page - 1) * per_page
    end = start + per_page

    return jsonify({
        'materials': materials[start:end],
        'total': total,
        'page': page,
        'per_page': per_page,
        'total_pages': (total + per_page - 1) // per_page
    })

@app.route('/api/material/<int:row_id>')
def get_material_detail(row_id):
    """获取材料详细信息"""
    db = get_db()

    try:
        row = db.get(id=row_id)
    except:
        return jsonify({'error': 'Material not found'}), 404

    # 获取mpid
    mpid = None
    if hasattr(row, 'mpid'):
        mpid = row.mpid
    elif 'mpid' in row.key_value_pairs:
        mpid = row.key_value_pairs['mpid']
    elif 'mpid' in row.data:
        mpid = row.data['mpid']

    # 基本信息
    detail = {
        'id': row.id,
        'mpid': mpid,
        'formula': row.formula if hasattr(row, 'formula') else 'N/A',
        'n_atoms': len(row.numbers) if hasattr(row, 'numbers') else 0,
        'symbols': [str(s) for s in row.symbols] if hasattr(row, 'symbols') else [],
        'numbers': [int(n) for n in row.numbers] if hasattr(row, 'numbers') else [],
    }

    # Hirshfeld数据
    if row.data:
        hirshfeld_data = {}
        for key in ['hirshfeld', 'hirshfeld_i', 'hirshfeld_i_relvol', 'hirshfeld_relvol']:
            if key in row.data:
                hirshfeld_data[key] = row.data[key]

        if hirshfeld_data:
            detail['hirshfeld'] = hirshfeld_data

    # 原子坐标（如果有）
    if hasattr(row, 'positions'):
        positions = row.positions
        detail['positions'] = positions.tolist() if hasattr(positions, 'tolist') else list(positions)

    # 晶胞参数（如果有）
    if hasattr(row, 'cell'):
        cell = row.cell
        detail['cell'] = cell.tolist() if hasattr(cell, 'tolist') else list(cell)

    # key_value_pairs
    if row.key_value_pairs:
        detail['properties'] = convert_to_json_serializable(row.key_value_pairs)

    # 确保所有数据都是JSON可序列化的
    detail = convert_to_json_serializable(detail)

    return jsonify(detail)

@app.route('/api/search')
def search_materials():
    """搜索材料"""
    query = request.args.get('q', '').strip()

    if not query:
        return jsonify({'materials': []})

    db = get_db()
    materials = []

    for row in db.select():
        mpid = None
        if hasattr(row, 'mpid'):
            mpid = row.mpid
        elif 'mpid' in row.key_value_pairs:
            mpid = row.key_value_pairs['mpid']
        elif 'mpid' in row.data:
            mpid = row.data['mpid']

        formula = row.formula if hasattr(row, 'formula') else ''

        # 搜索mpid或formula
        if query.lower() in (mpid or '').lower() or query.lower() in formula.lower():
            materials.append({
                'id': row.id,
                'mpid': mpid,
                'formula': formula,
                'has_hirshfeld': row.data and 'hirshfeld' in row.data
            })

    return jsonify({'materials': materials[:50]})  # 限制返回50个结果

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=1080, debug=True)
