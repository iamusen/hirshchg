#!/share/home/limusen/app/anaconda/anaconda3/envs/py14/bin/python
import h5py
import os
import numpy as np
from ase.db import connect

def get_mpids_from_db(db_path):
    """从ASE数据库读取所有mpid"""
    db = connect(db_path)
    mpids = []

    for row in db.select():
        if hasattr(row, 'mpid'):
            mpids.append(row.mpid)
        elif 'mpid' in row.key_value_pairs:
            mpids.append(row.key_value_pairs['mpid'])
        elif 'mpid' in row.data:
            mpids.append(row.data['mpid'])

    return mpids

def extract_hirshfeld_data(h5_path):
    """从HDF5文件中提取Hirshfeld电荷数据"""
    data = {}

    try:
        with h5py.File(h5_path, 'r') as f:
            hirshfeld_group = f['/results/hirshfeldcharge']

            datasets = ['hirshfeld', 'hirshfeld_i', 'hirshfeld_i_relvol', 'hirshfeld_relvol']

            for ds_name in datasets:
                if ds_name in hirshfeld_group:
                    data[ds_name] = hirshfeld_group[ds_name][:]
                else:
                    print(f"Warning: {ds_name} not found in {h5_path}")
                    data[ds_name] = None

    except Exception as e:
        print(f"Error reading {h5_path}: {e}")
        return None

    return data

def store_hirshfeld_data(db, mpid, data):
    """将Hirshfeld数据存入ASE数据库"""
    # 查找对应的row
    rows = list(db.select(mpid=mpid))

    if not rows:
        print(f"Warning: mpid {mpid} not found in database")
        return

    row_id = rows[0].id

    # 准备数据字典
    hirshfeld_data = {
        'hirshfeld': data['hirshfeld'].tolist() if data['hirshfeld'] is not None else None,
        'hirshfeld_i': data['hirshfeld_i'].tolist() if data['hirshfeld_i'] is not None else None,
        'hirshfeld_i_relvol': data['hirshfeld_i_relvol'].tolist() if data['hirshfeld_i_relvol'] is not None else None,
        'hirshfeld_relvol': data['hirshfeld_relvol'].tolist() if data['hirshfeld_relvol'] is not None else None,
    }

    # 更新数据库
    db.update(row_id, data=hirshfeld_data)

def main():
    db_path = 'h.db'
    hchg_dir = 'hchg'

    # 连接ASE数据库
    db = connect(db_path)

    # 获取所有mpid
    print("Reading mpids from database...")
    mpids = get_mpids_from_db(db_path)
    print(f"Found {len(mpids)} mpids")

    # 处理每个mpid
    success_count = 0
    fail_count = 0

    for i, mpid in enumerate(mpids, 1):
        h5_path = os.path.join(hchg_dir, mpid, 'scf', 'scf', 'vaspout.h5')

        if not os.path.exists(h5_path):
            print(f"[{i}/{len(mpids)}] Skipping {mpid}: file not found")
            fail_count += 1
            continue

        print(f"[{i}/{len(mpids)}] Processing {mpid}...")

        data = extract_hirshfeld_data(h5_path)

        if data is not None:
            store_hirshfeld_data(db, mpid, data)
            success_count += 1
            print(f"  ✓ Successfully extracted and stored data for {mpid}")
        else:
            fail_count += 1
            print(f"  ✗ Failed to extract data for {mpid}")

    print("\n" + "="*50)
    print(f"Processing complete!")
    print(f"Successfully processed: {success_count}")
    print(f"Failed: {fail_count}")
    print(f"Total: {len(mpids)}")

if __name__ == '__main__':
    main()
