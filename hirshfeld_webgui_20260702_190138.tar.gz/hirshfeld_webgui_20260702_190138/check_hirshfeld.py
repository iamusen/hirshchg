#!/share/home/limusen/app/anaconda/anaconda3/envs/py14/bin/python
from ase.db import connect

db = connect('h.db')

print("Checking hirshfeld data in h.db...\n")
print("=" * 70)

total_count = 0
hirshfeld_count = 0

for row in db.select():
    total_count += 1

    # 获取mpid
    mpid = None
    if hasattr(row, 'mpid'):
        mpid = row.mpid
    elif 'mpid' in row.key_value_pairs:
        mpid = row.key_value_pairs['mpid']
    elif 'mpid' in row.data:
        mpid = row.data['mpid']

    # 检查data字段中是否有hirshfeld数据
    has_hirshfeld = False
    hirshfeld_keys = []

    if row.data:
        for key in ['hirshfeld', 'hirshfeld_i', 'hirshfeld_i_relvol', 'hirshfeld_relvol']:
            if key in row.data:
                has_hirshfeld = True
                hirshfeld_keys.append(key)

    if has_hirshfeld:
        hirshfeld_count += 1
        print(f"Row {row.id}: mpid={mpid}")
        print(f"  Found hirshfeld keys: {hirshfeld_keys}")

        # 显示第一个条目的详细信息
        if hirshfeld_count == 1:
            print(f"  Sample data:")
            for key in hirshfeld_keys:
                data = row.data[key]
                if data:
                    print(f"    {key}: {type(data).__name__}, length={len(data) if hasattr(data, '__len__') else 'N/A'}")
                    if isinstance(data, list) and len(data) > 0:
                        print(f"      First few values: {data[:3]}")
        print()

print("=" * 70)
print(f"\nSummary:")
print(f"  Total rows in database: {total_count}")
print(f"  Rows with hirshfeld data: {hirshfeld_count}")
print(f"  Percentage: {100*hirshfeld_count/total_count:.1f}%" if total_count > 0 else "  N/A")
