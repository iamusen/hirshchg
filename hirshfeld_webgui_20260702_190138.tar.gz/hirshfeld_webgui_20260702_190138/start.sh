#!/bin/bash
# 启动Web服务的快捷脚本

echo "Starting Hirshfeld Database Web GUI..."
echo "Access the web interface at: http://localhost:5000"
echo "Press Ctrl+C to stop the server"
echo ""

python app.py
